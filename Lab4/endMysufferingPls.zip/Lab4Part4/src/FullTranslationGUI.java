import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * No issues with sequencing...
 */
public class FullTranslationGUI extends JFrame implements ActionListener {
    // Getting the resource bundle from the properties file
    ResourceBundle res = ResourceBundle.getBundle("ResourceProperty_en");

    // String array for the countries
    String[] countries = {res.getString("countryEN"), res.getString("countryFR")};

    // List of available calendar locales
    Locale[] locales = Calendar.getAvailableLocales();

    // The contentpane
    Container contentpane = getContentPane();

    // JPanel for each section
    JPanel comboBoxPanel = new JPanel();
    JPanel textAreaPanel = new JPanel();
    JPanel buttonPanel = new JPanel();

    // More JFrame components
    JButton button = new JButton(res.getString("buttonTag"));
    JTextArea textArea = new JTextArea(20, 20);
    JComboBox<String> language = new JComboBox<>(countries);

    public FullTranslationGUI() {
        // Other component settings
        textArea.setEditable(false);

        // Action listener for the button
        button.addActionListener(this);

        // The Panels
        comboBoxPanel.add(language);
        textAreaPanel.add(textArea);
        buttonPanel.add(button);

        // Add panels to contentpane
        contentpane.add(comboBoxPanel);
        contentpane.add(textAreaPanel);
        contentpane.add(buttonPanel);

        // JFrame methods to set
        setTitle("Full translating GUI");
        setVisible(true);
        setSize(500, 500);
        setLocation(400, 100);
        setLayout(new GridLayout(3, 1));

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) {
            System.out.println("Translate my suffering");
        }

    }
}
