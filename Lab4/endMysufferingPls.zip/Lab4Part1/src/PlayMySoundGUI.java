import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class PlayMySoundGUI extends JFrame implements ActionListener {
    File file = new File("InceptionFogHorn.wav");

    // Declare the contentpane
    Container contentpane = getContentPane();
    JButton play = new JButton("Play");
    JButton loop = new JButton("Loop");
    JButton stop = new JButton("Stop");

    public PlayMySoundGUI() {
        // If I put the method with the variable initialised here the scope won't allow it to be accessed in actionPerformed

        // Action listener's for buttons
        play.addActionListener(this);
        stop.addActionListener(this);
        loop.addActionListener(this);

        // JFrame content
        contentpane.add(play);
        contentpane.add(stop);
        contentpane.add(loop);

        setTitle("The sound");
        setVisible(true);
        setSize(500, 500);
        setLocation(400, 100);
        setLayout(new GridLayout(3, 1));
    }

    public static void main(String[] args) {
        new PlayMySoundGUI();
    }

    @Override
    public void actionPerformed(ActionEvent event) {

        // Unable to figure out how to use the file ONCE only

        // Added the included
        try {
            Clip theClip = getSound(file);

            if(theClip.isOpen()){

                theClip = getSound(file);

                if (event.getSource() == play) {
                    // Play the clip
                    theClip.start();


                } else if (event.getSource() == loop) {
                    // Loop the clip
                    theClip.loop(Clip.LOOP_CONTINUOUSLY);

                } else if (event.getSource() == stop) {
                    // Stop the clip
                    theClip.stop();

                }
            }



        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e){
            System.out.println("Great....");
            e.printStackTrace();
        }
    }

    public Clip getSound(File file) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
        // Get file from project directory
        System.out.println(file.toURI().toString());

        // Declare the Audio input class and print out the stream
        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(file)) {

            // Get a sound clip resource
            Clip clip = AudioSystem.getClip();


            // Open audio clip and load samples from input stream.
            clip.open(audioIn);

            return clip;

        }
    }
}
