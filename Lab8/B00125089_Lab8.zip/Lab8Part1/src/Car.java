public abstract class Car {
    public abstract String changeGearInstructions();
}
