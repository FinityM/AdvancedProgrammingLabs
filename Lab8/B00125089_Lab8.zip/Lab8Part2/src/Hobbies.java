public class Hobbies {
    public String name;

    public Hobbies(){}

    public Hobbies(String name){
        this.name = name;
    }

}
