/**
 * 
 */
package Mathematics;

/**
 * @author mcledera
 *
 */
public class MathHelper {

	/**
	 * 
	 * @param value to factor the number 
	 * @return int for the value 
	 * 
	 * */
	public static int recursiveFactorial(int value) {
		if (value == 1) {
			return 1;
			
		} else {
			return value * recursiveFactorial(value - 1);
		}
	}

}
