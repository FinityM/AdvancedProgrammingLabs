memberSearchIndex = [{
    "p": "<Unnamed>",
    "c": "MyMobileNetworkChecker",
    "l": "checkMyMobileNetwork(String)",
    "u": "checkMyMobileNetwork(java.lang.String)"
}, {
    "p": "<Unnamed>",
    "c": "MyMobileNetworkChecker",
    "l": "main(String[])",
    "u": "main(java.lang.String[])"
}, {
    "p": "<Unnamed>",
    "c": "MyMobileNetworkChecker",
    "l": "MyMobileNetworkChecker()",
    "u": "%3Cinit%3E()"
}, {
    "p": "<Unnamed>",
    "c": "NotMyNetworkClassException",
    "l": "NotMyNetworkClassException(String)",
    "u": "%3Cinit%3E(java.lang.String)"
}];
updateSearchResults();