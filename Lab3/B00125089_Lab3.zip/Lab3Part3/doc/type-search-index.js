typeSearchIndex = [{"l": "All Classes", "u": "allclasses-index.html"}, {
    "p": "<Unnamed>",
    "l": "MyMobileNetworkChecker"
}, {"p": "<Unnamed>", "l": "NotMyNetworkClassException"}];
updateSearchResults();