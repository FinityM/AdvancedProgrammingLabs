package com.raeside.family.exceptions;

public class SurnameMismatchException extends Exception {
    public SurnameMismatchException(String message) {
        super(message);
    }
}
