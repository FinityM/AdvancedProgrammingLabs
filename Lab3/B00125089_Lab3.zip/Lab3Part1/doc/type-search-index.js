typeSearchIndex = [{"l": "All Classes", "u": "allclasses-index.html"}, {"p": "<Unnamed>", "l": "Part1"}];
updateSearchResults();