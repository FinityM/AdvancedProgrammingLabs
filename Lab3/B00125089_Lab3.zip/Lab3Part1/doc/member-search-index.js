memberSearchIndex = [{
    "p": "<Unnamed>",
    "c": "Part1",
    "l": "main(String[])",
    "u": "main(java.lang.String[])"
}, {"p": "<Unnamed>", "c": "Part1", "l": "Part1()", "u": "%3Cinit%3E()"}];
updateSearchResults();