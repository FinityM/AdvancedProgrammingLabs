moduleSearchIndex = [];
updateSearchResults();