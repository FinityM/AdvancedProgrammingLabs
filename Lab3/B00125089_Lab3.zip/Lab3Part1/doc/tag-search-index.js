tagSearchIndex = [];
updateSearchResults();