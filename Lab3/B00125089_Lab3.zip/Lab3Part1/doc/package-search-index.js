packageSearchIndex = [{"l": "All Packages", "u": "allpackages-index.html"}];
updateSearchResults();